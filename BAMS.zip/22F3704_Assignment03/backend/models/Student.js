
const Blockchain = require('./Blockchain');

class Student {
  constructor(id, name, rollNumber, classId, departmentId, parentHash) {
    this.id = id;
    this.name = name;
    this.rollNumber = rollNumber;
    this.classId = classId;
    this.departmentId = departmentId;
    this.blockchain = new Blockchain('student', parentHash, {
      studentId: id,
      studentName: name,
      rollNumber: rollNumber,
      classId: classId,
      departmentId: departmentId
    });
  }

  // Mark attendance
  markAttendance(status, markedBy = 'admin') {
    const attendanceTransaction = {
      type: 'attendance',
      data: {
        studentId: this.id,
        studentName: this.name,
        rollNumber: this.rollNumber,
        classId: this.classId,
        departmentId: this.departmentId,
        status: status, // 'Present', 'Absent', 'Leave'
        markedBy: markedBy,
        date: new Date().toISOString().split('T')[0]
      },
      timestamp: Date.now()
    };
    
    return this.blockchain.addBlock(attendanceTransaction);
  }

  // Update student info (adds new block)
  updateStudent(newName, newRollNumber) {
    const updateTransaction = {
      type: 'update',
      data: {
        studentId: this.id,
        studentName: newName || this.name,
        rollNumber: newRollNumber || this.rollNumber,
        previousName: this.name,
        previousRollNumber: this.rollNumber,
        classId: this.classId,
        departmentId: this.departmentId
      },
      timestamp: Date.now()
    };
    
    this.blockchain.addBlock(updateTransaction);
    
    if (newName) this.name = newName;
    if (newRollNumber) this.rollNumber = newRollNumber;
  }

  // Delete student (adds deletion block)
  deleteStudent() {
    const deleteTransaction = {
      type: 'delete',
      status: 'deleted',
      data: {
        studentId: this.id,
        studentName: this.name,
        rollNumber: this.rollNumber,
        classId: this.classId,
        departmentId: this.departmentId
      },
      timestamp: Date.now()
    };
    
    this.blockchain.addBlock(deleteTransaction);
  }

  // Get all attendance records
  getAttendanceHistory() {
    return this.blockchain.getAllBlocks()
      .filter(block => block.transactions.type === 'attendance')
      .map(block => ({
        index: block.index,
        timestamp: block.timestamp,
        date: block.transactions.data.date,
        status: block.transactions.data.status,
        markedBy: block.transactions.data.markedBy,
        hash: block.hash,
        prevHash: block.prevHash,
        nonce: block.nonce
      }));
  }

  // Get attendance for a specific date
  getAttendanceByDate(date) {
    const history = this.getAttendanceHistory();
    return history.filter(record => record.date === date);
  }

  // Check if student is deleted
  isDeleted() {
    const state = this.blockchain.getCurrentState();
    return state.status === 'deleted';
  }

  // Get complete blockchain
  getFullBlockchain() {
    return this.blockchain.getAllBlocks();
  }
}

module.exports = Student;