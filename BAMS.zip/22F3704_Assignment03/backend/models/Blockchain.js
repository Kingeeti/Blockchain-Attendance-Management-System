
const Block = require('./Block');

class Blockchain {
  constructor(chainType, parentChainHash = null, metadata = {}) {
    this.chainType = chainType; // 'department', 'class', or 'student'
    this.chain = [];
    this.metadata = metadata; // Store department/class/student info
    
    // Create genesis block
    this.createGenesisBlock(parentChainHash);
  }

  createGenesisBlock(parentChainHash) {
    const genesisTransaction = {
      type: 'genesis',
      chainType: this.chainType,
      metadata: this.metadata,
      message: `Genesis block for ${this.chainType}`,
      timestamp: Date.now()
    };

    const genesisBlock = new Block(
      0,
      Date.now(),
      genesisTransaction,
      parentChainHash || '0'
    );
    
    genesisBlock.mineBlock(4);
    this.chain.push(genesisBlock);
  }

  getLatestBlock() {
    return this.chain[this.chain.length - 1];
  }

  addBlock(transactions) {
    const newBlock = new Block(
      this.chain.length,
      Date.now(),
      transactions,
      this.getLatestBlock().hash
    );
    
    newBlock.mineBlock(4);
    this.chain.push(newBlock);
    return newBlock;
  }

  // Validate entire blockchain
  isChainValid() {
    // Check genesis block
    if (this.chain.length === 0) return false;
    
    const genesisBlock = this.chain[0];
    if (!genesisBlock.isValid()) {
      console.log('Genesis block is invalid');
      return false;
    }

    // Validate all subsequent blocks
    for (let i = 1; i < this.chain.length; i++) {
      const currentBlock = this.chain[i];
      const previousBlock = this.chain[i - 1];

      // Check if current block is valid
      if (!currentBlock.isValid()) {
        console.log(`Block ${i} has invalid hash`);
        return false;
      }

      // Check if previous hash matches
      if (currentBlock.prevHash !== previousBlock.hash) {
        console.log(`Block ${i} has invalid previous hash link`);
        return false;
      }

      // Check PoW
      if (!currentBlock.hash.startsWith('0000')) {
        console.log(`Block ${i} doesn't meet PoW requirements`);
        return false;
      }
    }

    return true;
  }

  // Get all blocks
  getAllBlocks() {
    return this.chain;
  }

  // Get specific block by index
  getBlock(index) {
    return this.chain[index];
  }

  // Get chain length
  getChainLength() {
    return this.chain.length;
  }

  // Get the most recent non-deleted state from transactions
  getCurrentState() {
    // Traverse blocks from latest to oldest to find most recent state
    for (let i = this.chain.length - 1; i >= 0; i--) {
      const block = this.chain[i];
      const tx = block.transactions;
      
      if (tx.status === 'deleted') {
        return { status: 'deleted', deletedAt: block.timestamp };
      }
      
      if (tx.type === 'update' || tx.type === 'create' || tx.type === 'genesis') {
        return {
          status: 'active',
          data: tx.data || tx.metadata,
          updatedAt: block.timestamp
        };
      }
    }
    
    return { status: 'unknown' };
  }
}

module.exports = Blockchain;