
const { calculateHash } = require('../utils/hash');

class Block {
  constructor(index, timestamp, transactions, prevHash = '') {
    this.index = index;
    this.timestamp = timestamp;
    this.transactions = transactions;
    this.prevHash = prevHash;
    this.nonce = 0;
    this.hash = '';
  }

  // Mine block with Proof of Work (hash must start with "0000")
  mineBlock(difficulty = 4) {
    const target = '0'.repeat(difficulty);
    
    while (this.hash.substring(0, difficulty) !== target) {
      this.nonce++;
      this.hash = calculateHash(
        this.timestamp,
        this.transactions,
        this.prevHash,
        this.nonce
      );
    }
    
    console.log(`Block mined: ${this.hash}`);
  }

  // Calculate and set the hash for this block
  calculateBlockHash() {
    this.hash = calculateHash(
      this.timestamp,
      this.transactions,
      this.prevHash,
      this.nonce
    );
    return this.hash;
  }

  // Validate this block's hash
  isValid() {
    const calculatedHash = calculateHash(
      this.timestamp,
      this.transactions,
      this.prevHash,
      this.nonce
    );
    return this.hash === calculatedHash && this.hash.startsWith('0000');
  }
}

module.exports = Block;