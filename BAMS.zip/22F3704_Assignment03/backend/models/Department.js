
const Blockchain = require('./Blockchain');
const Class = require('./Class');

class Department {
  constructor(id, name) {
    this.id = id;
    this.name = name;
    this.blockchain = new Blockchain('department', null, {
      departmentId: id,
      departmentName: name
    });
    this.classes = {}; // Store class instances
  }

  // Add a new class under this department
  addClass(classId, className) {
    const parentHash = this.blockchain.getLatestBlock().hash;
    
    // Create a proper Class instance
    const classInstance = new Class(classId, className, this.id, parentHash);
    
    this.classes[classId] = classInstance;
    return classInstance;
  }

  // Update department (adds new block, doesn't modify existing)
  updateDepartment(newName) {
    const updateTransaction = {
      type: 'update',
      data: {
        departmentId: this.id,
        departmentName: newName,
        previousName: this.name
      },
      timestamp: Date.now()
    };
    
    this.blockchain.addBlock(updateTransaction);
    this.name = newName; // Update in-memory state
  }

  // Delete department (adds deletion block)
  deleteDepartment() {
    const deleteTransaction = {
      type: 'delete',
      status: 'deleted',
      data: {
        departmentId: this.id,
        departmentName: this.name
      },
      timestamp: Date.now()
    };
    
    this.blockchain.addBlock(deleteTransaction);
  }

  // Get class by ID
  getClass(classId) {
    return this.classes[classId];
  }

  // Get all classes
  getAllClasses() {
    return Object.values(this.classes).filter(c => {
      const state = c.blockchain.getCurrentState();
      return state.status !== 'deleted';
    });
  }

  // Validate department and all child chains
  validateComplete() {
    // Validate department chain
    if (!this.blockchain.isChainValid()) {
      return {
        valid: false,
        message: `Department ${this.name} chain is invalid`
      };
    }

    // Validate all class chains
    for (const classId in this.classes) {
      const classObj = this.classes[classId];
      
      if (!classObj.blockchain.isChainValid()) {
        return {
          valid: false,
          message: `Class ${classObj.name} chain is invalid`
        };
      }

      // Validate all students in this class
      for (const studentId in classObj.students) {
        const student = classObj.students[studentId];
        
        if (!student.blockchain.isChainValid()) {
          return {
            valid: false,
            message: `Student ${student.name} chain is invalid`
          };
        }
      }
    }

    return { valid: true, message: 'All chains valid' };
  }

  // Check if department is deleted
  isDeleted() {
    const state = this.blockchain.getCurrentState();
    return state.status === 'deleted';
  }
}

module.exports = Department;