
const Blockchain = require('./Blockchain');
const Student = require('./Student');

class Class {
  constructor(id, name, departmentId, parentHash) {
    this.id = id;
    this.name = name;
    this.departmentId = departmentId;
    this.blockchain = new Blockchain('class', parentHash, {
      classId: id,
      className: name,
      departmentId: departmentId
    });
    this.students = {};
  }

  // Add student to this class
  addStudent(studentId, studentName, rollNumber) {
    const parentHash = this.blockchain.getLatestBlock().hash;
    
    // Create a proper Student instance
    const studentInstance = new Student(
      studentId, 
      studentName, 
      rollNumber, 
      this.id, 
      this.departmentId, 
      parentHash
    );
    
    this.students[studentId] = studentInstance;
    return studentInstance;
  }

  // Update class (adds new block)
  updateClass(newName) {
    const updateTransaction = {
      type: 'update',
      data: {
        classId: this.id,
        className: newName,
        previousName: this.name,
        departmentId: this.departmentId
      },
      timestamp: Date.now()
    };
    
    this.blockchain.addBlock(updateTransaction);
    this.name = newName;
  }

  // Delete class (adds deletion block)
  deleteClass() {
    const deleteTransaction = {
      type: 'delete',
      status: 'deleted',
      data: {
        classId: this.id,
        className: this.name,
        departmentId: this.departmentId
      },
      timestamp: Date.now()
    };
    
    this.blockchain.addBlock(deleteTransaction);
  }

  // Get student by ID
  getStudent(studentId) {
    return this.students[studentId];
  }

  // Get all active students
  getAllStudents() {
    return Object.values(this.students).filter(s => {
      const state = s.blockchain.getCurrentState();
      return state.status !== 'deleted';
    });
  }

  // Check if class is deleted
  isDeleted() {
    const state = this.blockchain.getCurrentState();
    return state.status === 'deleted';
  }
}

module.exports = Class;