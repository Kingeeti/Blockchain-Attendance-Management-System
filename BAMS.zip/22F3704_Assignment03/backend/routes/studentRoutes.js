
const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');

// Create student
router.post('/', studentController.createStudent);

// Get all students
router.get('/', studentController.getAllStudents);

// Search student
router.get('/search', studentController.searchStudent);

// Get students by class
router.get('/class/:departmentId/:classId', studentController.getStudentsByClass);

// Get student blockchain
router.get('/:departmentId/:classId/:studentId/blockchain', studentController.getStudentBlockchain);

// Get student by ID
router.get('/:departmentId/:classId/:studentId', studentController.getStudentById);

// Update student
router.put('/:departmentId/:classId/:studentId', studentController.updateStudent);

// Delete student
router.delete('/:departmentId/:classId/:studentId', studentController.deleteStudent);

module.exports = router;