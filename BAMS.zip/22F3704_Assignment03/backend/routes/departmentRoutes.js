
const express = require('express');
const router = express.Router();
const departmentController = require('../controllers/departmentController');

// Create department
router.post('/', departmentController.createDepartment);

// Get all departments
router.get('/', departmentController.getAllDepartments);

// Search department
router.get('/search', departmentController.searchDepartment);

// Get department by ID
router.get('/:id', departmentController.getDepartmentById);

// Update department
router.put('/:id', departmentController.updateDepartment);

// Delete department
router.delete('/:id', departmentController.deleteDepartment);

// Validate department blockchain
router.get('/:id/validate', departmentController.validateDepartment);

module.exports = router;