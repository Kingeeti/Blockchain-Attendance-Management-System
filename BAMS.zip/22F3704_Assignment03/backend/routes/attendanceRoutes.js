
const express = require('express');
const router = express.Router();
const attendanceController = require('../controllers/attendanceController');

// Mark attendance for a student
router.post('/:departmentId/:classId/:studentId', attendanceController.markAttendance);

// Get student attendance history
router.get('/:departmentId/:classId/:studentId', attendanceController.getStudentAttendance);

// Get attendance by specific date
router.get('/:departmentId/:classId/:studentId/date', attendanceController.getAttendanceByDate);

// Get today's attendance for a class
router.get('/class/:departmentId/:classId/today', attendanceController.getTodayAttendanceByClass);

// Get today's attendance for entire department
router.get('/department/:departmentId/today', attendanceController.getTodayAttendanceByDepartment);

// Bulk mark attendance for class
router.post('/class/:departmentId/:classId/bulk', attendanceController.bulkMarkAttendance);

// Validate complete system
router.get('/validate/system', attendanceController.validateSystem);

module.exports = router;