
const express = require('express');
const router = express.Router();
const classController = require('../controllers/classController');

// Create class
router.post('/', classController.createClass);

// Get all classes
router.get('/', classController.getAllClasses);

// Search class
router.get('/search', classController.searchClass);

// Get classes by department
router.get('/department/:departmentId', classController.getClassesByDepartment);

// Get class by ID
router.get('/:departmentId/:classId', classController.getClassById);

// Update class
router.put('/:departmentId/:classId', classController.updateClass);

// Delete class
router.delete('/:departmentId/:classId', classController.deleteClass);

module.exports = router;