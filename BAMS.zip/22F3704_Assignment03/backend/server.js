
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

// Import routes
const departmentRoutes = require('./routes/departmentRoutes');
const classRoutes = require('./routes/classRoutes');
const studentRoutes = require('./routes/studentRoutes');
const attendanceRoutes = require('./routes/attendanceRoutes');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors()); // Enable CORS for all routes
app.use(bodyParser.json()); // Parse JSON request bodies
app.use(bodyParser.urlencoded({ extended: true })); // Parse URL-encoded bodies

// Logging middleware - logs all incoming requests
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// API Routes
app.use('/api/departments', departmentRoutes);
app.use('/api/classes', classRoutes);
app.use('/api/students', studentRoutes);
app.use('/api/attendance', attendanceRoutes);

// Root endpoint - API information
app.get('/', (req, res) => {
  res.json({
    message: 'Blockchain-Based Attendance Management System API',
    version: '1.0.0',
    description: 'Multi-layered hierarchical blockchain system for attendance management',
    author: 'Your Name',
    endpoints: {
      departments: '/api/departments',
      classes: '/api/classes',
      students: '/api/students',
      attendance: '/api/attendance'
    },
    documentation: {
      departments: {
        'POST /api/departments': 'Create a new department',
        'GET /api/departments': 'Get all departments',
        'GET /api/departments/:id': 'Get department by ID',
        'GET /api/departments/search?name=': 'Search departments',
        'PUT /api/departments/:id': 'Update department',
        'DELETE /api/departments/:id': 'Delete department',
        'GET /api/departments/:id/validate': 'Validate department blockchain'
      },
      classes: {
        'POST /api/classes': 'Create a new class',
        'GET /api/classes': 'Get all classes',
        'GET /api/classes/department/:departmentId': 'Get classes by department',
        'GET /api/classes/:departmentId/:classId': 'Get class by ID',
        'GET /api/classes/search?name=': 'Search classes',
        'PUT /api/classes/:departmentId/:classId': 'Update class',
        'DELETE /api/classes/:departmentId/:classId': 'Delete class'
      },
      students: {
        'POST /api/students': 'Create a new student',
        'GET /api/students': 'Get all students',
        'GET /api/students/class/:departmentId/:classId': 'Get students by class',
        'GET /api/students/:departmentId/:classId/:studentId': 'Get student by ID',
        'GET /api/students/search?query=': 'Search students',
        'PUT /api/students/:departmentId/:classId/:studentId': 'Update student',
        'DELETE /api/students/:departmentId/:classId/:studentId': 'Delete student',
        'GET /api/students/:departmentId/:classId/:studentId/blockchain': 'Get student blockchain'
      },
      attendance: {
        'POST /api/attendance/:departmentId/:classId/:studentId': 'Mark attendance',
        'GET /api/attendance/:departmentId/:classId/:studentId': 'Get student attendance history',
        'GET /api/attendance/:departmentId/:classId/:studentId/date?date=': 'Get attendance by date',
        'GET /api/attendance/class/:departmentId/:classId/today': 'Get today\'s class attendance',
        'GET /api/attendance/department/:departmentId/today': 'Get today\'s department attendance',
        'POST /api/attendance/class/:departmentId/:classId/bulk': 'Bulk mark attendance',
        'GET /api/attendance/validate/system': 'Validate complete blockchain system'
      }
    },
    features: [
      'Multi-layered blockchain (Department → Class → Student)',
      'SHA-256 cryptographic hashing',
      'Proof of Work (PoW) mining',
      'Immutable blockchain records',
      'Hierarchical chain linking',
      'Complete CRUD operations',
      'Real-time validation',
      'Attendance tracking'
    ]
  });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
});

// API status endpoint
app.get('/api/status', (req, res) => {
  res.json({
    api: 'Blockchain Attendance Management System',
    status: 'Running',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error occurred:', err);
  res.status(err.status || 500).json({ 
    error: 'Internal server error',
    message: err.message,
    path: req.path,
    timestamp: new Date().toISOString()
  });
});

// 404 handler - must be last
app.use((req, res) => {
  res.status(404).json({ 
    error: 'Route not found',
    path: req.path,
    method: req.method,
    message: 'The requested endpoint does not exist',
    availableEndpoints: [
      '/api/departments',
      '/api/classes',
      '/api/students',
      '/api/attendance'
    ]
  });
});

// Start server
app.listen(PORT, () => {
  console.clear();
  console.log('='.repeat(70));
  console.log('🔗  BLOCKCHAIN-BASED ATTENDANCE MANAGEMENT SYSTEM');
  console.log('='.repeat(70));
  console.log(`✅  Server Status: RUNNING`);
  console.log(`🌐  Server URL: http://localhost:${PORT}`);
  console.log(`🏥  Health Check: http://localhost:${PORT}/health`);
  console.log(`📚  API Documentation: http://localhost:${PORT}/`);
  console.log('='.repeat(70));
  console.log('📡  Available API Endpoints:');
  console.log(`   • Departments: http://localhost:${PORT}/api/departments`);
  console.log(`   • Classes:     http://localhost:${PORT}/api/classes`);
  console.log(`   • Students:    http://localhost:${PORT}/api/students`);
  console.log(`   • Attendance:  http://localhost:${PORT}/api/attendance`);
  console.log('='.repeat(70));
  console.log('🔐  Features Enabled:');
  console.log('   ✓ Multi-layered Blockchain');
  console.log('   ✓ SHA-256 Hashing');
  console.log('   ✓ Proof of Work (PoW)');
  console.log('   ✓ Hierarchical Chain Linking');
  console.log('   ✓ Complete CRUD Operations');
  console.log('   ✓ Real-time Validation');
  console.log('='.repeat(70));
  console.log('⏳  Waiting for requests...\n');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('\n⚠️  SIGTERM signal received: closing HTTP server');
  server.close(() => {
    console.log('✅  HTTP server closed');
  });
});

process.on('SIGINT', () => {
  console.log('\n\n⚠️  Server shutting down...');
  process.exit(0);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('❌  Uncaught Exception:', err);
  process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌  Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

module.exports = app;