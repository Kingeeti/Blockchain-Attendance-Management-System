

/**
 * Validation utility for multi-level blockchain hierarchy
 * This validates the entire 3-layer blockchain structure:
 * Department → Class → Student → Attendance
 */

class ValidationUtil {
  /**
   * Validate entire system: Department -> Class -> Student -> Attendance
   * This is the main validation function that checks all blockchain layers
   * 
   * @param {Object} departments - Object containing all departments
   * @returns {Object} Validation results with details for each layer
   */
  static validateCompleteSystem(departments) {
    const results = {
      valid: true,
      departmentResults: [],
      classResults: [],
      studentResults: [],
      errors: []
    };

    for (const deptId in departments) {
      const dept = departments[deptId];
      
      // 1. Validate Department Chain
      const deptValidation = this.validateDepartmentChain(dept);
      results.departmentResults.push(deptValidation);
      
      if (!deptValidation.valid) {
        results.valid = false;
        results.errors.push(`Department ${dept.name}: ${deptValidation.message}`);
        continue;
      }

      // 2. Validate all Class Chains under this department
      for (const classId in dept.classes) {
        const classObj = dept.classes[classId];
        const classValidation = this.validateClassChain(classObj, dept);
        results.classResults.push(classValidation);
        
        if (!classValidation.valid) {
          results.valid = false;
          results.errors.push(`Class ${classObj.name}: ${classValidation.message}`);
          continue;
        }

        // 3. Validate all Student Chains under this class
        for (const studentId in classObj.students) {
          const student = classObj.students[studentId];
          const studentValidation = this.validateStudentChain(student, classObj);
          results.studentResults.push(studentValidation);
          
          if (!studentValidation.valid) {
            results.valid = false;
            results.errors.push(`Student ${student.name}: ${studentValidation.message}`);
          }
        }
      }
    }

    return results;
  }

  /**
   * Validate a department's blockchain
   * Checks if the department chain is internally valid
   * 
   * @param {Object} department - Department object with blockchain
   * @returns {Object} Validation result
   */
  static validateDepartmentChain(department) {
    if (!department.blockchain.isChainValid()) {
      return {
        valid: false,
        departmentId: department.id,
        departmentName: department.name,
        message: 'Department blockchain is invalid'
      };
    }

    return {
      valid: true,
      departmentId: department.id,
      departmentName: department.name,
      message: 'Department blockchain is valid'
    };
  }

  /**
   * Validate a class's blockchain and its link to parent department
   * Checks both internal validity and hierarchical linking
   * 
   * @param {Object} classObj - Class object with blockchain
   * @param {Object} parentDepartment - Parent department object
   * @returns {Object} Validation result
   */
  static validateClassChain(classObj, parentDepartment) {
    // Validate class chain itself
    if (!classObj.blockchain.isChainValid()) {
      return {
        valid: false,
        classId: classObj.id,
        className: classObj.name,
        message: 'Class blockchain is invalid'
      };
    }

    // Validate that class genesis block links to department's chain
    const classGenesisBlock = classObj.blockchain.getBlock(0);
    
    // Get all hashes from department chain
    const deptHashes = parentDepartment.blockchain.getAllBlocks().map(b => b.hash);
    
    // Check if class genesis block's prevHash exists in department chain
    // (or is '0' for independent chains, though classes should link to department)
    if (!deptHashes.includes(classGenesisBlock.prevHash) && classGenesisBlock.prevHash !== '0') {
      return {
        valid: false,
        classId: classObj.id,
        className: classObj.name,
        message: 'Class genesis block does not link to parent department chain'
      };
    }

    return {
      valid: true,
      classId: classObj.id,
      className: classObj.name,
      message: 'Class blockchain is valid and properly linked'
    };
  }

  /**
   * Validate a student's blockchain and its link to parent class
   * Checks internal validity, hierarchical linking, and all attendance records
   * 
   * @param {Object} student - Student object with blockchain
   * @param {Object} parentClass - Parent class object
   * @returns {Object} Validation result
   */
  static validateStudentChain(student, parentClass) {
    // Validate student chain itself
    if (!student.blockchain.isChainValid()) {
      return {
        valid: false,
        studentId: student.id,
        studentName: student.name,
        message: 'Student blockchain is invalid'
      };
    }

    // Validate that student genesis block links to class chain
    const studentGenesisBlock = student.blockchain.getBlock(0);
    const classHashes = parentClass.blockchain.getAllBlocks().map(b => b.hash);
    
    if (!classHashes.includes(studentGenesisBlock.prevHash) && studentGenesisBlock.prevHash !== '0') {
      return {
        valid: false,
        studentId: student.id,
        studentName: student.name,
        message: 'Student genesis block does not link to parent class chain'
      };
    }

    // Validate all attendance blocks
    const attendanceBlocks = student.blockchain.getAllBlocks()
      .filter(block => block.transactions.type === 'attendance');
    
    for (const block of attendanceBlocks) {
      if (!block.isValid()) {
        return {
          valid: false,
          studentId: student.id,
          studentName: student.name,
          message: `Attendance block ${block.index} is invalid`
        };
      }

      // Verify Proof of Work (hash must start with "0000")
      if (!block.hash.startsWith('0000')) {
        return {
          valid: false,
          studentId: student.id,
          studentName: student.name,
          message: `Attendance block ${block.index} does not meet PoW requirements`
        };
      }
    }

    return {
      valid: true,
      studentId: student.id,
      studentName: student.name,
      message: 'Student blockchain is valid with all attendance records verified'
    };
  }

  /**
   * Validate a single blockchain (generic validation)
   * Can be used to validate any blockchain independently
   * 
   * @param {Object} blockchain - Blockchain object
   * @returns {boolean} True if valid, false otherwise
   */
  static validateSingleChain(blockchain) {
    return blockchain.isChainValid();
  }

  /**
   * Check if tampering occurred in any part of the hierarchy
   * Returns detailed information about where tampering was detected
   * 
   * @param {Object} departments - All departments
   * @returns {Object} Tampering detection results
   */
  static detectTampering(departments) {
    const tamperingResults = {
      tampered: false,
      locations: []
    };

    const validation = this.validateCompleteSystem(departments);
    
    if (!validation.valid) {
      tamperingResults.tampered = true;
      tamperingResults.locations = validation.errors;
    }

    return tamperingResults;
  }

  /**
   * Validate hierarchical links between all layers
   * Specifically checks if child chains properly link to parent chains
   * 
   * @param {Object} departments - All departments
   * @returns {Object} Link validation results
   */
  static validateHierarchicalLinks(departments) {
    const linkResults = {
      valid: true,
      brokenLinks: []
    };

    for (const deptId in departments) {
      const dept = departments[deptId];

      // Check class links to department
      for (const classId in dept.classes) {
        const classObj = dept.classes[classId];
        const classGenesis = classObj.blockchain.getBlock(0);
        const deptHashes = dept.blockchain.getAllBlocks().map(b => b.hash);

        if (!deptHashes.includes(classGenesis.prevHash)) {
          linkResults.valid = false;
          linkResults.brokenLinks.push({
            type: 'class-to-department',
            classId: classObj.id,
            className: classObj.name,
            departmentId: dept.id,
            departmentName: dept.name
          });
        }

        // Check student links to class
        for (const studentId in classObj.students) {
          const student = classObj.students[studentId];
          const studentGenesis = student.blockchain.getBlock(0);
          const classHashes = classObj.blockchain.getAllBlocks().map(b => b.hash);

          if (!classHashes.includes(studentGenesis.prevHash)) {
            linkResults.valid = false;
            linkResults.brokenLinks.push({
              type: 'student-to-class',
              studentId: student.id,
              studentName: student.name,
              classId: classObj.id,
              className: classObj.name
            });
          }
        }
      }
    }

    return linkResults;
  }
}

module.exports = ValidationUtil;