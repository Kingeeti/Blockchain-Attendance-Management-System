
const crypto = require('crypto');

/**
 * Calculate SHA-256 hash for block data
 * This function combines all block components and generates a cryptographic hash
 * 
 * @param {number} timestamp - Block timestamp
 * @param {any} transactions - Transaction data (attendance, metadata, etc.)
 * @param {string} prevHash - Previous block hash
 * @param {number} nonce - Nonce value for Proof of Work
 * @returns {string} SHA-256 hash in hexadecimal format
 */
function calculateHash(timestamp, transactions, prevHash, nonce) {
  // Combine all block data into a single string
  const data = timestamp + JSON.stringify(transactions) + prevHash + nonce;
  
  // Generate SHA-256 hash
  return crypto.createHash('sha256').update(data).digest('hex');
}

module.exports = { calculateHash };