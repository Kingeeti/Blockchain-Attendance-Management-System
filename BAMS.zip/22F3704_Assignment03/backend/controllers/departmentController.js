
const Department = require('../models/Department');

// In-memory storage (you can replace with database)
let departments = {};

// Initialize with default departments
function initializeDefaultDepartments() {
  if (Object.keys(departments).length === 0) {
    // Create School of Computing
    const soc = new Department('dept_001', 'School of Computing');
    departments[soc.id] = soc;

    // Create School of Software Engineering
    const sse = new Department('dept_002', 'School of Software Engineering');
    departments[sse.id] = sse;

    console.log('Default departments initialized');
  }
}

// Create new department
exports.createDepartment = (req, res) => {
  try {
    const { name } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Department name is required' });
    }

    const id = `dept_${Date.now()}`;
    const department = new Department(id, name);
    departments[id] = department;

    res.status(201).json({
      message: 'Department created successfully',
      department: {
        id: department.id,
        name: department.name,
        blockchain: department.blockchain.getAllBlocks()
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all departments
exports.getAllDepartments = (req, res) => {
  try {
    initializeDefaultDepartments();
    
    const deptList = Object.values(departments)
      .filter(dept => !dept.isDeleted())
      .map(dept => ({
        id: dept.id,
        name: dept.name,
        classCount: dept.getAllClasses().length,
        chainLength: dept.blockchain.getChainLength()
      }));

    res.json({
      departments: deptList,
      total: deptList.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get department by ID
exports.getDepartmentById = (req, res) => {
  try {
    const { id } = req.params;
    const department = departments[id];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    if (department.isDeleted()) {
      return res.status(404).json({ error: 'Department has been deleted' });
    }

    res.json({
      id: department.id,
      name: department.name,
      classes: department.getAllClasses().map(c => ({
        id: c.id,
        name: c.name,
        studentCount: c.getAllStudents().length
      })),
      blockchain: department.blockchain.getAllBlocks()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Search department by name
exports.searchDepartment = (req, res) => {
  try {
    const { name } = req.query;
    
    if (!name) {
      return res.status(400).json({ error: 'Search name is required' });
    }

    const results = Object.values(departments)
      .filter(dept => 
        !dept.isDeleted() && 
        dept.name.toLowerCase().includes(name.toLowerCase())
      )
      .map(dept => ({
        id: dept.id,
        name: dept.name,
        classCount: dept.getAllClasses().length
      }));

    res.json({
      results,
      count: results.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update department (adds new block to blockchain)
exports.updateDepartment = (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;

    const department = departments[id];
    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    if (department.isDeleted()) {
      return res.status(400).json({ error: 'Cannot update deleted department' });
    }

    if (!name) {
      return res.status(400).json({ error: 'New name is required' });
    }

    department.updateDepartment(name);

    res.json({
      message: 'Department updated successfully (new block added)',
      department: {
        id: department.id,
        name: department.name,
        blockchain: department.blockchain.getAllBlocks()
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete department (adds deletion block to blockchain)
exports.deleteDepartment = (req, res) => {
  try {
    const { id } = req.params;
    const department = departments[id];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    if (department.isDeleted()) {
      return res.status(400).json({ error: 'Department already deleted' });
    }

    department.deleteDepartment();

    res.json({
      message: 'Department deleted successfully (deletion block added)',
      department: {
        id: department.id,
        name: department.name,
        status: 'deleted',
        blockchain: department.blockchain.getAllBlocks()
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Validate department blockchain
exports.validateDepartment = (req, res) => {
  try {
    const { id } = req.params;
    const department = departments[id];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const validation = department.validateComplete();

    res.json({
      departmentId: id,
      departmentName: department.name,
      validation
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Export departments data structure for use in other controllers
exports.getDepartmentsData = () => {
  initializeDefaultDepartments();
  return departments;
};