const { getDepartmentsData } = require('./departmentController');
const ValidationUtil = require('../utils/validation');

// Mark attendance for a student
exports.markAttendance = (req, res) => {
  try {
    const { departmentId, classId, studentId } = req.params;
    const { status, markedBy } = req.body;

    if (!status || !['Present', 'Absent', 'Leave'].includes(status)) {
      return res.status(400).json({ 
        error: 'Valid status is required (Present, Absent, or Leave)' 
      });
    }

    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const student = classObj.getStudent(studentId);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    if (student.isDeleted()) {
      return res.status(400).json({ 
        error: 'Cannot mark attendance for deleted student' 
      });
    }

    const block = student.markAttendance(status, markedBy || 'admin');

    res.status(201).json({
      message: 'Attendance marked successfully',
      attendance: {
        studentId: student.id,
        studentName: student.name,
        rollNumber: student.rollNumber,
        status: status,
        date: new Date().toISOString().split('T')[0],
        block: {
          index: block.index,
          hash: block.hash,
          prevHash: block.prevHash,
          nonce: block.nonce,
          timestamp: block.timestamp
        }
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get attendance history for a student
exports.getStudentAttendance = (req, res) => {
  try {
    const { departmentId, classId, studentId } = req.params;
    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const student = classObj.getStudent(studentId);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const history = student.getAttendanceHistory();

    res.json({
      studentId: student.id,
      studentName: student.name,
      rollNumber: student.rollNumber,
      attendanceRecords: history,
      totalRecords: history.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get today's attendance for a class
exports.getTodayAttendanceByClass = (req, res) => {
  try {
    const { departmentId, classId } = req.params;
    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const today = new Date().toISOString().split('T')[0];
    const students = classObj.getAllStudents();
    const attendanceList = [];

    students.forEach(student => {
      const todayRecords = student.getAttendanceByDate(today);
      const latestRecord = todayRecords.length > 0 
        ? todayRecords[todayRecords.length - 1] 
        : null;

      attendanceList.push({
        studentId: student.id,
        studentName: student.name,
        rollNumber: student.rollNumber,
        status: latestRecord ? latestRecord.status : 'Not Marked',
        timestamp: latestRecord ? latestRecord.timestamp : null
      });
    });

    res.json({
      classId: classObj.id,
      className: classObj.name,
      departmentId: department.id,
      departmentName: department.name,
      date: today,
      attendance: attendanceList,
      total: attendanceList.length,
      present: attendanceList.filter(a => a.status === 'Present').length,
      absent: attendanceList.filter(a => a.status === 'Absent').length,
      leave: attendanceList.filter(a => a.status === 'Leave').length,
      notMarked: attendanceList.filter(a => a.status === 'Not Marked').length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get today's attendance for entire department
exports.getTodayAttendanceByDepartment = (req, res) => {
  try {
    const { departmentId } = req.params;
    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const today = new Date().toISOString().split('T')[0];
    const classes = department.getAllClasses();
    const departmentAttendance = [];

    classes.forEach(classObj => {
      const students = classObj.getAllStudents();
      const classAttendance = [];

      students.forEach(student => {
        const todayRecords = student.getAttendanceByDate(today);
        const latestRecord = todayRecords.length > 0 
          ? todayRecords[todayRecords.length - 1] 
          : null;

        classAttendance.push({
          studentId: student.id,
          studentName: student.name,
          rollNumber: student.rollNumber,
          status: latestRecord ? latestRecord.status : 'Not Marked'
        });
      });

      departmentAttendance.push({
        classId: classObj.id,
        className: classObj.name,
        students: classAttendance,
        present: classAttendance.filter(a => a.status === 'Present').length,
        absent: classAttendance.filter(a => a.status === 'Absent').length,
        leave: classAttendance.filter(a => a.status === 'Leave').length,
        notMarked: classAttendance.filter(a => a.status === 'Not Marked').length
      });
    });

    const totalStats = {
      present: departmentAttendance.reduce((sum, c) => sum + c.present, 0),
      absent: departmentAttendance.reduce((sum, c) => sum + c.absent, 0),
      leave: departmentAttendance.reduce((sum, c) => sum + c.leave, 0),
      notMarked: departmentAttendance.reduce((sum, c) => sum + c.notMarked, 0)
    };

    res.json({
      departmentId: department.id,
      departmentName: department.name,
      date: today,
      classes: departmentAttendance,
      totalClasses: departmentAttendance.length,
      statistics: totalStats
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get attendance for specific date
exports.getAttendanceByDate = (req, res) => {
  try {
    const { departmentId, classId, studentId } = req.params;
    const { date } = req.query;

    if (!date) {
      return res.status(400).json({ error: 'Date is required (YYYY-MM-DD)' });
    }

    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const student = classObj.getStudent(studentId);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const records = student.getAttendanceByDate(date);

    res.json({
      studentId: student.id,
      studentName: student.name,
      rollNumber: student.rollNumber,
      date: date,
      records: records,
      count: records.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Validate complete system
exports.validateSystem = (req, res) => {
  try {
    const departments = getDepartmentsData();
    const validation = ValidationUtil.validateCompleteSystem(departments);

    res.json({
      systemValid: validation.valid,
      validation: validation
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Bulk mark attendance for entire class
exports.bulkMarkAttendance = (req, res) => {
  try {
    const { departmentId, classId } = req.params;
    const { attendanceData, markedBy } = req.body;
    
    // attendanceData should be array of { studentId, status }
    if (!Array.isArray(attendanceData)) {
      return res.status(400).json({ 
        error: 'Attendance data must be an array' 
      });
    }

    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const results = [];
    const errors = [];

    attendanceData.forEach(record => {
      try {
        const { studentId, status } = record;
        
        if (!['Present', 'Absent', 'Leave'].includes(status)) {
          errors.push({
            studentId,
            error: 'Invalid status'
          });
          return;
        }

        const student = classObj.getStudent(studentId);
        if (!student || student.isDeleted()) {
          errors.push({
            studentId,
            error: 'Student not found or deleted'
          });
          return;
        }

        const block = student.markAttendance(status, markedBy || 'admin');
        results.push({
          studentId: student.id,
          studentName: student.name,
          status: status,
          blockHash: block.hash
        });
      } catch (err) {
        errors.push({
          studentId: record.studentId,
          error: err.message
        });
      }
    });

    res.json({
      message: 'Bulk attendance marking completed',
      successful: results.length,
      failed: errors.length,
      results: results,
      errors: errors
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};