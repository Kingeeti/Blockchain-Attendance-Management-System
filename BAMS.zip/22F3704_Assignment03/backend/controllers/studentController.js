
const { getDepartmentsData } = require('./departmentController');

// Create new student
exports.createStudent = (req, res) => {
  try {
    const { departmentId, classId, name, rollNumber } = req.body;
    
    if (!departmentId || !classId || !name || !rollNumber) {
      return res.status(400).json({ 
        error: 'Department ID, class ID, name, and roll number are required' 
      });
    }

    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    if (classObj.isDeleted()) {
      return res.status(400).json({ 
        error: 'Cannot add student to deleted class' 
      });
    }

    const studentId = `student_${Date.now()}`;
    const student = classObj.addStudent(studentId, name, rollNumber);

    res.status(201).json({
      message: 'Student created successfully',
      student: {
        id: student.id,
        name: student.name,
        rollNumber: student.rollNumber,
        classId: student.classId,
        departmentId: student.departmentId,
        blockchain: student.blockchain.getAllBlocks()
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all students
exports.getAllStudents = (req, res) => {
  try {
    const departments = getDepartmentsData();
    const allStudents = [];

    for (const deptId in departments) {
      const dept = departments[deptId];
      if (!dept.isDeleted()) {
        for (const classId in dept.classes) {
          const classObj = dept.classes[classId];
          if (!classObj.isDeleted()) {
            const students = classObj.getAllStudents();
            students.forEach(s => {
              allStudents.push({
                id: s.id,
                name: s.name,
                rollNumber: s.rollNumber,
                classId: classObj.id,
                className: classObj.name,
                departmentId: dept.id,
                departmentName: dept.name,
                chainLength: s.blockchain.getChainLength()
              });
            });
          }
        }
      }
    }

    res.json({
      students: allStudents,
      total: allStudents.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get students by class
exports.getStudentsByClass = (req, res) => {
  try {
    const { departmentId, classId } = req.params;
    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const students = classObj.getAllStudents().map(s => ({
      id: s.id,
      name: s.name,
      rollNumber: s.rollNumber,
      classId: s.classId,
      departmentId: s.departmentId,
      chainLength: s.blockchain.getChainLength()
    }));

    res.json({
      classId,
      className: classObj.name,
      departmentId,
      departmentName: department.name,
      students,
      total: students.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get student by ID
exports.getStudentById = (req, res) => {
  try {
    const { departmentId, classId, studentId } = req.params;
    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const student = classObj.getStudent(studentId);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    if (student.isDeleted()) {
      return res.status(404).json({ error: 'Student has been deleted' });
    }

    res.json({
      id: student.id,
      name: student.name,
      rollNumber: student.rollNumber,
      classId: student.classId,
      departmentId: student.departmentId,
      attendanceHistory: student.getAttendanceHistory(),
      blockchain: student.blockchain.getAllBlocks()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Search student by name or roll number
exports.searchStudent = (req, res) => {
  try {
    const { query } = req.query;
    
    if (!query) {
      return res.status(400).json({ error: 'Search query is required' });
    }

    const departments = getDepartmentsData();
    const results = [];

    for (const deptId in departments) {
      const dept = departments[deptId];
      if (!dept.isDeleted()) {
        for (const classId in dept.classes) {
          const classObj = dept.classes[classId];
          if (!classObj.isDeleted()) {
            const students = classObj.getAllStudents();
            students.forEach(s => {
              if (
                s.name.toLowerCase().includes(query.toLowerCase()) ||
                s.rollNumber.toLowerCase().includes(query.toLowerCase())
              ) {
                results.push({
                  id: s.id,
                  name: s.name,
                  rollNumber: s.rollNumber,
                  classId: classObj.id,
                  className: classObj.name,
                  departmentId: dept.id,
                  departmentName: dept.name
                });
              }
            });
          }
        }
      }
    }

    res.json({
      results,
      count: results.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update student (adds new block to blockchain)
exports.updateStudent = (req, res) => {
  try {
    const { departmentId, classId, studentId } = req.params;
    const { name, rollNumber } = req.body;

    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const student = classObj.getStudent(studentId);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    if (student.isDeleted()) {
      return res.status(400).json({ error: 'Cannot update deleted student' });
    }

    student.updateStudent(name, rollNumber);

    res.json({
      message: 'Student updated successfully (new block added)',
      student: {
        id: student.id,
        name: student.name,
        rollNumber: student.rollNumber,
        classId: student.classId,
        departmentId: student.departmentId,
        blockchain: student.blockchain.getAllBlocks()
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete student (adds deletion block to blockchain)
exports.deleteStudent = (req, res) => {
  try {
    const { departmentId, classId, studentId } = req.params;
    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const student = classObj.getStudent(studentId);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    if (student.isDeleted()) {
      return res.status(400).json({ error: 'Student already deleted' });
    }

    student.deleteStudent();

    res.json({
      message: 'Student deleted successfully (deletion block added)',
      student: {
        id: student.id,
        name: student.name,
        rollNumber: student.rollNumber,
        status: 'deleted',
        blockchain: student.blockchain.getAllBlocks()
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get student's complete blockchain
exports.getStudentBlockchain = (req, res) => {
  try {
    const { departmentId, classId, studentId } = req.params;
    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    const student = classObj.getStudent(studentId);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    res.json({
      studentId: student.id,
      studentName: student.name,
      rollNumber: student.rollNumber,
      blockchain: student.getFullBlockchain(),
      isValid: student.blockchain.isChainValid()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};