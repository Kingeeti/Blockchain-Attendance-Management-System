
const { getDepartmentsData } = require('./departmentController');

// Create new class under a department
exports.createClass = (req, res) => {
  try {
    const { departmentId, name } = req.body;
    
    if (!departmentId || !name) {
      return res.status(400).json({ 
        error: 'Department ID and class name are required' 
      });
    }

    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    if (department.isDeleted()) {
      return res.status(400).json({ 
        error: 'Cannot add class to deleted department' 
      });
    }

    const classId = `class_${Date.now()}`;
    const classObj = department.addClass(classId, name);

    res.status(201).json({
      message: 'Class created successfully',
      class: {
        id: classObj.id,
        name: classObj.name,
        departmentId: classObj.departmentId,
        blockchain: classObj.blockchain.getAllBlocks()
      }
    });
  } catch (error) {
    console.error('Error in createClass:', error);
    res.status(500).json({ error: error.message });
  }
};

// Get all classes - FIXED VERSION
exports.getAllClasses = (req, res) => {
  try {
    const departments = getDepartmentsData();
    const allClasses = [];

    for (const deptId in departments) {
      const dept = departments[deptId];
      if (!dept.isDeleted()) {
        // Get all class objects from department
        const classObjects = Object.values(dept.classes);
        
        classObjects.forEach(c => {
          // Check if class is deleted
          const state = c.blockchain.getCurrentState();
          if (state.status !== 'deleted') {
            // Count students safely
            let studentCount = 0;
            if (c.students) {
              studentCount = Object.values(c.students).filter(s => {
                const studentState = s.blockchain.getCurrentState();
                return studentState.status !== 'deleted';
              }).length;
            }
            
            allClasses.push({
              id: c.id,
              name: c.name,
              departmentId: dept.id,
              departmentName: dept.name,
              studentCount: studentCount,
              chainLength: c.blockchain.getChainLength()
            });
          }
        });
      }
    }

    res.json({
      classes: allClasses,
      total: allClasses.length
    });
  } catch (error) {
    console.error('Error in getAllClasses:', error);
    res.status(500).json({ error: error.message });
  }
};

// Get classes by department
exports.getClassesByDepartment = (req, res) => {
  try {
    const { departmentId } = req.params;
    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObjects = Object.values(department.classes);
    const classes = classObjects
      .filter(c => {
        const state = c.blockchain.getCurrentState();
        return state.status !== 'deleted';
      })
      .map(c => {
        // Count students safely
        let studentCount = 0;
        if (c.students) {
          studentCount = Object.values(c.students).filter(s => {
            const studentState = s.blockchain.getCurrentState();
            return studentState.status !== 'deleted';
          }).length;
        }
        
        return {
          id: c.id,
          name: c.name,
          departmentId: c.departmentId,
          studentCount: studentCount,
          chainLength: c.blockchain.getChainLength()
        };
      });

    res.json({
      departmentId,
      departmentName: department.name,
      classes,
      total: classes.length
    });
  } catch (error) {
    console.error('Error in getClassesByDepartment:', error);
    res.status(500).json({ error: error.message });
  }
};

// Get class by ID
exports.getClassById = (req, res) => {
  try {
    const { departmentId, classId } = req.params;
    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    if (classObj.isDeleted()) {
      return res.status(404).json({ error: 'Class has been deleted' });
    }

    // Get students safely
    const students = [];
    if (classObj.students) {
      const studentObjects = Object.values(classObj.students);
      studentObjects.forEach(s => {
        const state = s.blockchain.getCurrentState();
        if (state.status !== 'deleted') {
          students.push({
            id: s.id,
            name: s.name,
            rollNumber: s.rollNumber
          });
        }
      });
    }

    res.json({
      id: classObj.id,
      name: classObj.name,
      departmentId: classObj.departmentId,
      students: students,
      blockchain: classObj.blockchain.getAllBlocks()
    });
  } catch (error) {
    console.error('Error in getClassById:', error);
    res.status(500).json({ error: error.message });
  }
};

// Search class by name
exports.searchClass = (req, res) => {
  try {
    const { name } = req.query;
    
    if (!name) {
      return res.status(400).json({ error: 'Search name is required' });
    }

    const departments = getDepartmentsData();
    const results = [];

    for (const deptId in departments) {
      const dept = departments[deptId];
      if (!dept.isDeleted()) {
        const classObjects = Object.values(dept.classes);
        
        classObjects.forEach(c => {
          const state = c.blockchain.getCurrentState();
          if (state.status !== 'deleted' && c.name.toLowerCase().includes(name.toLowerCase())) {
            // Count students safely
            let studentCount = 0;
            if (c.students) {
              studentCount = Object.values(c.students).filter(s => {
                const studentState = s.blockchain.getCurrentState();
                return studentState.status !== 'deleted';
              }).length;
            }
            
            results.push({
              id: c.id,
              name: c.name,
              departmentId: dept.id,
              departmentName: dept.name,
              studentCount: studentCount
            });
          }
        });
      }
    }

    res.json({
      results,
      count: results.length
    });
  } catch (error) {
    console.error('Error in searchClass:', error);
    res.status(500).json({ error: error.message });
  }
};

// Update class (adds new block to blockchain)
exports.updateClass = (req, res) => {
  try {
    const { departmentId, classId } = req.params;
    const { name } = req.body;

    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    if (classObj.isDeleted()) {
      return res.status(400).json({ error: 'Cannot update deleted class' });
    }

    if (!name) {
      return res.status(400).json({ error: 'New name is required' });
    }

    classObj.updateClass(name);

    res.json({
      message: 'Class updated successfully (new block added)',
      class: {
        id: classObj.id,
        name: classObj.name,
        departmentId: classObj.departmentId,
        blockchain: classObj.blockchain.getAllBlocks()
      }
    });
  } catch (error) {
    console.error('Error in updateClass:', error);
    res.status(500).json({ error: error.message });
  }
};

// Delete class (adds deletion block to blockchain)
exports.deleteClass = (req, res) => {
  try {
    const { departmentId, classId } = req.params;
    const departments = getDepartmentsData();
    const department = departments[departmentId];

    if (!department) {
      return res.status(404).json({ error: 'Department not found' });
    }

    const classObj = department.getClass(classId);
    if (!classObj) {
      return res.status(404).json({ error: 'Class not found' });
    }

    if (classObj.isDeleted()) {
      return res.status(400).json({ error: 'Class already deleted' });
    }

    classObj.deleteClass();

    res.json({
      message: 'Class deleted successfully (deletion block added)',
      class: {
        id: classObj.id,
        name: classObj.name,
        status: 'deleted',
        blockchain: classObj.blockchain.getAllBlocks()
      }
    });
  } catch (error) {
    console.error('Error in deleteClass:', error);
    res.status(500).json({ error: error.message });
  }
};