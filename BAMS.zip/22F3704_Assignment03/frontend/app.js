

// API Base URL
const API_URL = 'http://localhost:3000/api';

// ==================== TAB MANAGEMENT ====================

function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabName).classList.add('active');
    event.target.classList.add('active');
    
    // Load data for the tab
    switch(tabName) {
        case 'departments':
            loadDepartments();
            break;
        case 'classes':
            loadClasses();
            loadDepartmentSelects();
            break;
        case 'students':
            loadStudents();
            loadDepartmentSelects();
            break;
        case 'attendance':
            loadDepartmentSelects();
            break;
    }
}

// ==================== UTILITY FUNCTIONS ====================

function showStatus(message, type = 'success') {
    const statusEl = document.getElementById('statusMessage');
    statusEl.textContent = message;
    statusEl.className = `status-message ${type}`;
    statusEl.style.display = 'block';
    
    setTimeout(() => {
        statusEl.style.display = 'none';
    }, 3000);
}

function closeModal() {
    document.getElementById('detailModal').style.display = 'none';
}

function createBlockchainHTML(block) {
    return `
        <div class="blockchain-block">
            <div class="block-header">Block #${block.index}</div>
            <div class="block-field"><strong>Timestamp:</strong> ${new Date(block.timestamp).toLocaleString()}</div>
            <div class="block-field"><strong>Hash:</strong> ${block.hash}</div>
            <div class="block-field"><strong>Previous Hash:</strong> ${block.prevHash}</div>
            <div class="block-field"><strong>Nonce:</strong> ${block.nonce}</div>
            <div class="block-field"><strong>Transaction:</strong> ${JSON.stringify(block.transactions, null, 2)}</div>
        </div>
    `;
}

// ==================== DEPARTMENT FUNCTIONS ====================

async function createDepartment() {
    const name = document.getElementById('deptName').value;
    
    if (!name) {
        showStatus('Please enter department name', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/departments`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus('Department created successfully!', 'success');
            document.getElementById('deptName').value = '';
            loadDepartments();
        } else {
            showStatus(data.error || 'Failed to create department', 'error');
        }
    } catch (error) {
        showStatus('Error: ' + error.message, 'error');
    }
}

async function loadDepartments() {
    try {
        const response = await fetch(`${API_URL}/departments`);
        const data = await response.json();
        
        const container = document.getElementById('departmentsList');
        container.innerHTML = '';
        
        if (data.departments && data.departments.length > 0) {
            data.departments.forEach(dept => {
                const item = createDepartmentItem(dept);
                container.appendChild(item);
            });
        } else {
            container.innerHTML = '<p style="text-align: center; color: #999;">No departments found</p>';
        }
    } catch (error) {
        showStatus('Error loading departments: ' + error.message, 'error');
    }
}

function createDepartmentItem(dept) {
    const div = document.createElement('div');
    div.className = 'list-item';
    div.innerHTML = `
        <h4>${dept.name}</h4>
        <p><strong>ID:</strong> ${dept.id}</p>
        <p><strong>Classes:</strong> ${dept.classCount}</p>
        <p><strong>Chain Length:</strong> ${dept.chainLength} blocks</p>
        <div class="actions">
            <button onclick="viewDepartmentDetails('${dept.id}')">View Details</button>
            <button onclick="updateDepartmentPrompt('${dept.id}', '${dept.name}')" class="btn-warning">Update</button>
            <button onclick="deleteDepartment('${dept.id}')" class="btn-danger">Delete</button>
        </div>
    `;
    return div;
}

async function searchDepartments() {
    const name = document.getElementById('deptSearch').value;
    
    if (!name) {
        showStatus('Please enter search term', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/departments/search?name=${encodeURIComponent(name)}`);
        const data = await response.json();
        
        const container = document.getElementById('departmentsList');
        container.innerHTML = '';
        
        if (data.results && data.results.length > 0) {
            data.results.forEach(dept => {
                const item = createDepartmentItem(dept);
                container.appendChild(item);
            });
        } else {
            container.innerHTML = '<p style="text-align: center; color: #999;">No departments found</p>';
        }
    } catch (error) {
        showStatus('Error searching departments: ' + error.message, 'error');
    }
}

async function viewDepartmentDetails(id) {
    try {
        const response = await fetch(`${API_URL}/departments/${id}`);
        const data = await response.json();
        
        let html = `
            <h2>${data.name}</h2>
            <p><strong>ID:</strong> ${data.id}</p>
            <p><strong>Number of Classes:</strong> ${data.classes.length}</p>
            <h3>Classes:</h3>
        `;
        
        if (data.classes.length > 0) {
            data.classes.forEach(cls => {
                html += `<p>• ${cls.name} (${cls.studentCount} students)</p>`;
            });
        } else {
            html += '<p>No classes in this department</p>';
        }
        
        html += '<h3>Blockchain:</h3>';
        data.blockchain.forEach(block => {
            html += createBlockchainHTML(block);
        });
        
        document.getElementById('modalBody').innerHTML = html;
        document.getElementById('detailModal').style.display = 'block';
    } catch (error) {
        showStatus('Error loading department details: ' + error.message, 'error');
    }
}

function updateDepartmentPrompt(id, currentName) {
    const newName = prompt(`Update department name (current: ${currentName}):`, currentName);
    if (newName && newName !== currentName) {
        updateDepartment(id, newName);
    }
}

async function updateDepartment(id, name) {
    try {
        const response = await fetch(`${API_URL}/departments/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus('Department updated successfully!', 'success');
            loadDepartments();
        } else {
            showStatus(data.error || 'Failed to update department', 'error');
        }
    } catch (error) {
        showStatus('Error: ' + error.message, 'error');
    }
}

async function deleteDepartment(id) {
    if (!confirm('Are you sure you want to delete this department? This will add a deletion block to the blockchain.')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/departments/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus('Department deleted (deletion block added)!', 'success');
            loadDepartments();
        } else {
            showStatus(data.error || 'Failed to delete department', 'error');
        }
    } catch (error) {
        showStatus('Error: ' + error.message, 'error');
    }
}

// ==================== CLASS FUNCTIONS ====================

async function createClass() {
    const departmentId = document.getElementById('classDeptSelect').value;
    const name = document.getElementById('className').value;
    
    if (!departmentId || !name) {
        showStatus('Please select department and enter class name', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/classes`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ departmentId, name })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus('Class created successfully!', 'success');
            document.getElementById('className').value = '';
            loadClasses();
        } else {
            showStatus(data.error || 'Failed to create class', 'error');
        }
    } catch (error) {
        showStatus('Error: ' + error.message, 'error');
    }
}

async function loadClasses() {
    try {
        const response = await fetch(`${API_URL}/classes`);
        const data = await response.json();
        
        const container = document.getElementById('classesList');
        container.innerHTML = '';
        
        if (data.classes && data.classes.length > 0) {
            data.classes.forEach(cls => {
                const item = createClassItem(cls);
                container.appendChild(item);
            });
        } else {
            container.innerHTML = '<p style="text-align: center; color: #999;">No classes found</p>';
        }
    } catch (error) {
        showStatus('Error loading classes: ' + error.message, 'error');
    }
}

function createClassItem(cls) {
    const div = document.createElement('div');
    div.className = 'list-item';
    div.innerHTML = `
        <h4>${cls.name}</h4>
        <p><strong>ID:</strong> ${cls.id}</p>
        <p><strong>Department:</strong> ${cls.departmentName}</p>
        <p><strong>Students:</strong> ${cls.studentCount}</p>
        <p><strong>Chain Length:</strong> ${cls.chainLength} blocks</p>
        <div class="actions">
            <button onclick="viewClassDetails('${cls.departmentId}', '${cls.id}')">View Details</button>
            <button onclick="updateClassPrompt('${cls.departmentId}', '${cls.id}', '${cls.name}')" class="btn-warning">Update</button>
            <button onclick="deleteClass('${cls.departmentId}', '${cls.id}')" class="btn-danger">Delete</button>
        </div>
    `;
    return div;
}

async function searchClasses() {
    const name = document.getElementById('classSearch').value;
    
    if (!name) {
        showStatus('Please enter search term', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/classes/search?name=${encodeURIComponent(name)}`);
        const data = await response.json();
        
        const container = document.getElementById('classesList');
        container.innerHTML = '';
        
        if (data.results && data.results.length > 0) {
            data.results.forEach(cls => {
                const item = createClassItem(cls);
                container.appendChild(item);
            });
        } else {
            container.innerHTML = '<p style="text-align: center; color: #999;">No classes found</p>';
        }
    } catch (error) {
        showStatus('Error searching classes: ' + error.message, 'error');
    }
}

async function viewClassDetails(deptId, classId) {
    try {
        const response = await fetch(`${API_URL}/classes/${deptId}/${classId}`);
        const data = await response.json();
        
        let html = `
            <h2>${data.name}</h2>
            <p><strong>ID:</strong> ${data.id}</p>
            <p><strong>Department ID:</strong> ${data.departmentId}</p>
            <p><strong>Number of Students:</strong> ${data.students.length}</p>
            <h3>Students:</h3>
        `;
        
        if (data.students.length > 0) {
            data.students.forEach(student => {
                html += `<p>• ${student.name} (Roll: ${student.rollNumber})</p>`;
            });
        } else {
            html += '<p>No students in this class</p>';
        }
        
        html += '<h3>Blockchain:</h3>';
        data.blockchain.forEach(block => {
            html += createBlockchainHTML(block);
        });
        
        document.getElementById('modalBody').innerHTML = html;
        document.getElementById('detailModal').style.display = 'block';
    } catch (error) {
        showStatus('Error loading class details: ' + error.message, 'error');
    }
}

function updateClassPrompt(deptId, classId, currentName) {
    const newName = prompt(`Update class name (current: ${currentName}):`, currentName);
    if (newName && newName !== currentName) {
        updateClass(deptId, classId, newName);
    }
}

async function updateClass(deptId, classId, name) {
    try {
        const response = await fetch(`${API_URL}/classes/${deptId}/${classId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus('Class updated successfully!', 'success');
            loadClasses();
        } else {
            showStatus(data.error || 'Failed to update class', 'error');
        }
    } catch (error) {
        showStatus('Error: ' + error.message, 'error');
    }
}

async function deleteClass(deptId, classId) {
    if (!confirm('Are you sure you want to delete this class?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/classes/${deptId}/${classId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus('Class deleted (deletion block added)!', 'success');
            loadClasses();
        } else {
            showStatus(data.error || 'Failed to delete class', 'error');
        }
    } catch (error) {
        showStatus('Error: ' + error.message, 'error');
    }
}

// ==================== STUDENT FUNCTIONS ====================

async function createStudent() {
    const departmentId = document.getElementById('studentDeptSelect').value;
    const classId = document.getElementById('studentClassSelect').value;
    const name = document.getElementById('studentName').value;
    const rollNumber = document.getElementById('studentRoll').value;
    
    if (!departmentId || !classId || !name || !rollNumber) {
        showStatus('Please fill all fields', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/students`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ departmentId, classId, name, rollNumber })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus('Student created successfully!', 'success');
            document.getElementById('studentName').value = '';
            document.getElementById('studentRoll').value = '';
            loadStudents();
        } else {
            showStatus(data.error || 'Failed to create student', 'error');
        }
    } catch (error) {
        showStatus('Error: ' + error.message, 'error');
    }
}

async function loadStudents() {
    try {
        const response = await fetch(`${API_URL}/students`);
        const data = await response.json();
        
        const container = document.getElementById('studentsList');
        container.innerHTML = '';
        
        if (data.students && data.students.length > 0) {
            data.students.forEach(student => {
                const item = createStudentItem(student);
                container.appendChild(item);
            });
        } else {
            container.innerHTML = '<p style="text-align: center; color: #999;">No students found</p>';
        }
    } catch (error) {
        showStatus('Error loading students: ' + error.message, 'error');
    }
}

function createStudentItem(student) {
    const div = document.createElement('div');
    div.className = 'list-item';
    div.innerHTML = `
        <h4>${student.name}</h4>
        <p><strong>Roll Number:</strong> ${student.rollNumber}</p>
        <p><strong>Class:</strong> ${student.className}</p>
        <p><strong>Department:</strong> ${student.departmentName}</p>
        <p><strong>Chain Length:</strong> ${student.chainLength} blocks</p>
        <div class="actions">
            <button onclick="viewStudentDetails('${student.departmentId}', '${student.classId}', '${student.id}')">View Details</button>
            <button onclick="updateStudentPrompt('${student.departmentId}', '${student.classId}', '${student.id}', '${student.name}', '${student.rollNumber}')" class="btn-warning">Update</button>
            <button onclick="deleteStudent('${student.departmentId}', '${student.classId}', '${student.id}')" class="btn-danger">Delete</button>
        </div>
    `;
    return div;
}

async function searchStudents() {
    const query = document.getElementById('studentSearch').value;
    
    if (!query) {
        showStatus('Please enter search term', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/students/search?query=${encodeURIComponent(query)}`);
        const data = await response.json();
        
        const container = document.getElementById('studentsList');
        container.innerHTML = '';
        
        if (data.results && data.results.length > 0) {
            data.results.forEach(student => {
                const item = createStudentItem(student);
                container.appendChild(item);
            });
        } else {
            container.innerHTML = '<p style="text-align: center; color: #999;">No students found</p>';
        }
    } catch (error) {
        showStatus('Error searching students: ' + error.message, 'error');
    }
}

async function viewStudentDetails(deptId, classId, studentId) {
    try {
        const response = await fetch(`${API_URL}/students/${deptId}/${classId}/${studentId}`);
        const data = await response.json();
        
        let html = `
            <h2>${data.name}</h2>
            <p><strong>Roll Number:</strong> ${data.rollNumber}</p>
            <p><strong>ID:</strong> ${data.id}</p>
            <p><strong>Class ID:</strong> ${data.classId}</p>
            <p><strong>Department ID:</strong> ${data.departmentId}</p>
            <h3>Attendance History (${data.attendanceHistory.length} records):</h3>
        `;
        
        if (data.attendanceHistory.length > 0) {
            data.attendanceHistory.forEach(record => {
                html += `
                    <div style="background: #f0f0f0; padding: 10px; margin: 5px 0; border-radius: 5px;">
                        <strong>${record.date}</strong>: 
                        <span class="status-badge status-${record.status.toLowerCase()}">${record.status}</span>
                        <br><small>Block ${record.index} - Hash: ${record.hash.substring(0, 16)}...</small>
                    </div>
                `;
            });
        } else {
            html += '<p>No attendance records</p>';
        }
        
        html += '<h3>Complete Blockchain:</h3>';
        data.blockchain.forEach(block => {
            html += createBlockchainHTML(block);
        });
        
        document.getElementById('modalBody').innerHTML = html;
        document.getElementById('detailModal').style.display = 'block';
    } catch (error) {
        showStatus('Error loading student details: ' + error.message, 'error');
    }
}

function updateStudentPrompt(deptId, classId, studentId, currentName, currentRoll) {
    const newName = prompt(`Update student name (current: ${currentName}):`, currentName);
    const newRoll = prompt(`Update roll number (current: ${currentRoll}):`, currentRoll);
    
    if ((newName && newName !== currentName) || (newRoll && newRoll !== currentRoll)) {
        updateStudent(deptId, classId, studentId, newName || currentName, newRoll || currentRoll);
    }
}

async function updateStudent(deptId, classId, studentId, name, rollNumber) {
    try {
        const response = await fetch(`${API_URL}/students/${deptId}/${classId}/${studentId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, rollNumber })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus('Student updated successfully!', 'success');
            loadStudents();
        } else {
            showStatus(data.error || 'Failed to update student', 'error');
        }
    } catch (error) {
        showStatus('Error: ' + error.message, 'error');
    }
}

async function deleteStudent(deptId, classId, studentId) {
    if (!confirm('Are you sure you want to delete this student?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/students/${deptId}/${classId}/${studentId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus('Student deleted (deletion block added)!', 'success');
            loadStudents();
        } else {
            showStatus(data.error || 'Failed to delete student', 'error');
        }
    } catch (error) {
        showStatus('Error: ' + error.message, 'error');
    }
}

// ==================== ATTENDANCE FUNCTIONS ====================

async function loadTodayAttendance() {
    const deptId = document.getElementById('attDeptSelect').value;
    const classId = document.getElementById('attClassSelect').value;
    
    if (!deptId || !classId) {
        showStatus('Please select department and class', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/attendance/class/${deptId}/${classId}/today`);
        const data = await response.json();
        
        const container = document.getElementById('attendanceList');
        container.innerHTML = `
            <div class="card">
                <h3>Today's Attendance - ${data.className}</h3>
                <p><strong>Date:</strong> ${data.date}</p>
                <p><strong>Present:</strong> ${data.present} | <strong>Absent:</strong> ${data.absent} | <strong>Leave:</strong> ${data.leave} | <strong>Not Marked:</strong> ${data.notMarked}</p>
            </div>
            <div class="attendance-grid"></div>
        `;
        
        const grid = container.querySelector('.attendance-grid');
        
        data.attendance.forEach(att => {
            const card = document.createElement('div');
            card.className = 'attendance-card';
            card.innerHTML = `
                <h5>${att.studentName}</h5>
                <p>Roll: ${att.rollNumber}</p>
                <p>Status: <span class="status-badge status-${att.status.toLowerCase().replace(' ', '-')}">${att.status}</span></p>
                <div class="status-buttons">
                    <button class="btn-success" onclick="markAttendance('${deptId}', '${classId}', '${att.studentId}', 'Present')">Present</button>
                    <button class="btn-danger" onclick="markAttendance('${deptId}', '${classId}', '${att.studentId}', 'Absent')">Absent</button>
                    <button class="btn-warning" onclick="markAttendance('${deptId}', '${classId}', '${att.studentId}', 'Leave')">Leave</button>
                </div>
            `;
            grid.appendChild(card);
        });
    } catch (error) {
        showStatus('Error loading attendance: ' + error.message, 'error');
    }
}

async function markAttendance(deptId, classId, studentId, status) {
    try {
        const response = await fetch(`${API_URL}/attendance/${deptId}/${classId}/${studentId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status, markedBy: 'Admin' })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showStatus(`Attendance marked as ${status}!`, 'success');
            loadTodayAttendance();
        } else {
            showStatus(data.error || 'Failed to mark attendance', 'error');
        }
    } catch (error) {
        showStatus('Error: ' + error.message, 'error');
    }
}

async function viewAttendanceHistory() {
    const deptId = document.getElementById('historyDeptId').value;
    const classId = document.getElementById('historyClassId').value;
    const studentId = document.getElementById('historyStudentId').value;
    
    if (!deptId || !classId || !studentId) {
        showStatus('Please fill all fields', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/attendance/${deptId}/${classId}/${studentId}`);
        const data = await response.json();
        
        const container = document.getElementById('attendanceHistory');
        container.innerHTML = `
            <div class="card">
                <h3>Attendance History - ${data.studentName}</h3>
                <p><strong>Roll Number:</strong> ${data.rollNumber}</p>
                <p><strong>Total Records:</strong> ${data.totalRecords}</p>
            </div>
        `;
        
        if (data.attendanceRecords.length > 0) {
            data.attendanceRecords.forEach(record => {
                const item = document.createElement('div');
                item.className = 'list-item';
                item.innerHTML = `
                    <h4>${record.date} <span class="status-badge status-${record.status.toLowerCase()}">${record.status}</span></h4>
                    <p><strong>Block Index:</strong> ${record.index}</p>
                    <p><strong>Timestamp:</strong> ${new Date(record.timestamp).toLocaleString()}</p>
                    <p><strong>Hash:</strong> ${record.hash}</p>
                    <p><strong>Previous Hash:</strong> ${record.prevHash}</p>
                    <p><strong>Nonce:</strong> ${record.nonce}</p>
                    <p><strong>Marked By:</strong> ${record.markedBy}</p>
                `;
                container.appendChild(item);
            });
        } else {
            container.innerHTML += '<p style="text-align: center; color: #999;">No attendance records found</p>';
        }
    } catch (error) {
        showStatus('Error loading attendance history: ' + error.message, 'error');
    }
}

// ==================== VALIDATION FUNCTIONS ====================

async function validateSystem() {
    showStatus('Running complete system validation...', 'info');
    
    try {
        const response = await fetch(`${API_URL}/attendance/validate/system`);
        const data = await response.json();
        
        const container = document.getElementById('validationResults');
        container.innerHTML = `
            <div class="card ${data.systemValid ? '' : 'invalid'}">
                <h3>System Validation Result</h3>
                <p><strong>Status:</strong> ${data.systemValid ? '✅ VALID' : '❌ INVALID'}</p>
            </div>
        `;
        
        // Department results
        if (data.validation.departmentResults.length > 0) {
            const deptCard = document.createElement('div');
            deptCard.className = 'card';
            deptCard.innerHTML = '<h3>Department Chains</h3>';
            data.validation.departmentResults.forEach(result => {
                deptCard.innerHTML += `
                    <div class="validation-result ${result.valid ? '' : 'invalid'}">
                        <h5>${result.departmentName}</h5>
                        <p>${result.message}</p>
                    </div>
                `;
            });
            container.appendChild(deptCard);
        }
        
        // Class results
        if (data.validation.classResults.length > 0) {
            const classCard = document.createElement('div');
            classCard.className = 'card';
            classCard.innerHTML = '<h3>Class Chains</h3>';
            data.validation.classResults.forEach(result => {
                classCard.innerHTML += `
                    <div class="validation-result ${result.valid ? '' : 'invalid'}">
                        <h5>${result.className}</h5>
                        <p>${result.message}</p>
                    </div>
                `;
            });
            container.appendChild(classCard);
        }
        
        // Student results
        if (data.validation.studentResults.length > 0) {
            const studentCard = document.createElement('div');
            studentCard.className = 'card';
            studentCard.innerHTML = '<h3>Student Chains</h3>';
            data.validation.studentResults.forEach(result => {
                studentCard.innerHTML += `
                    <div class="validation-result ${result.valid ? '' : 'invalid'}">
                        <h5>${result.studentName}</h5>
                        <p>${result.message}</p>
                    </div>
                `;
            });
            container.appendChild(studentCard);
        }
        
        showStatus(data.systemValid ? 'System validation successful!' : 'System validation found errors!', data.systemValid ? 'success' : 'error');
    } catch (error) {
        showStatus('Error validating system: ' + error.message, 'error');
    }
}

async function viewStudentBlockchain() {
    const deptId = document.getElementById('blockchainDeptId').value;
    const classId = document.getElementById('blockchainClassId').value;
    const studentId = document.getElementById('blockchainStudentId').value;
    
    if (!deptId || !classId || !studentId) {
        showStatus('Please fill all fields', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/students/${deptId}/${classId}/${studentId}/blockchain`);
        const data = await response.json();
        
        const container = document.getElementById('blockchainView');
        container.innerHTML = `
            <div class="card">
                <h3>${data.studentName}'s Blockchain</h3>
                <p><strong>Roll Number:</strong> ${data.rollNumber}</p>
                <p><strong>Valid:</strong> ${data.isValid ? '✅ YES' : '❌ NO'}</p>
                <p><strong>Total Blocks:</strong> ${data.blockchain.length}</p>
            </div>
        `;
        
        data.blockchain.forEach(block => {
            container.innerHTML += createBlockchainHTML(block);
        });
    } catch (error) {
        showStatus('Error loading blockchain: ' + error.message, 'error');
    }
}

// ==================== HELPER FUNCTIONS ====================

async function loadDepartmentSelects() {
    try {
        const response = await fetch(`${API_URL}/departments`);
        const data = await response.json();
        
        const selects = [
            document.getElementById('classDeptSelect'),
            document.getElementById('studentDeptSelect'),
            document.getElementById('attDeptSelect')
        ];
        
        selects.forEach(select => {
            if (select) {
                select.innerHTML = '<option value="">Select Department</option>';
                data.departments.forEach(dept => {
                    select.innerHTML += `<option value="${dept.id}">${dept.name}</option>`;
                });
            }
        });
    } catch (error) {
        console.error('Error loading departments:', error);
    }
}

async function loadClassesForStudent() {
    const deptId = document.getElementById('studentDeptSelect').value;
    const select = document.getElementById('studentClassSelect');
    
    select.innerHTML = '<option value="">Select Class</option>';
    
    if (!deptId) return;
    
    try {
        const response = await fetch(`${API_URL}/classes/department/${deptId}`);
        const data = await response.json();
        
        data.classes.forEach(cls => {
            select.innerHTML += `<option value="${cls.id}">${cls.name}</option>`;
        });
    } catch (error) {
        console.error('Error loading classes:', error);
    }
}

async function loadClassesForAttendance() {
    const deptId = document.getElementById('attDeptSelect').value;
    const select = document.getElementById('attClassSelect');
    
    select.innerHTML = '<option value="">Select Class</option>';
    
    if (!deptId) return;
    
    try {
        const response = await fetch(`${API_URL}/classes/department/${deptId}`);
        const data = await response.json();
        
        data.classes.forEach(cls => {
            select.innerHTML += `<option value="${cls.id}">${cls.name}</option>`;
        });
    } catch (error) {
        console.error('Error loading classes:', error);
    }
}

async function loadStudentsForAttendance() {
    // This function can be used if you want to pre-load student data
    // Currently not needed as loadTodayAttendance() handles it
}

// ==================== INITIALIZATION ====================

// Initialize on load
window.addEventListener('DOMContentLoaded', () => {
    console.log('🔗 Blockchain Attendance System - Frontend Loaded');
    loadDepartments();
    loadDepartmentSelects();
});